In order to use the new files: 
-- copy them *inside* the simdlab folder.
-- use make -f Makefile.poly clean to erase the old versions. 
-- use make -f Makefile.poly to run the benchmarks.
